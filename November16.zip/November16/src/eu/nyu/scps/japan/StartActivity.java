package eu.nyu.scps.japan;


import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Toast;


public class StartActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
        final LinearLayout root = (LinearLayout) findViewById(R.id.myscreen);         
		Spinner spinner = new Spinner(StartActivity.this);
		root.addView(spinner, 1);				
	    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
	    		StartActivity.this, R.array.graphics_array, android.R.layout.simple_spinner_item);
	    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	    spinner.setAdapter(adapter);
		
	    spinner.setOnItemSelectedListener(
                new OnItemSelectedListener() {
                    public void onItemSelected(
                            AdapterView<?> parent, View view, int position, long id) {
                    	getPosition(Integer.toString(position));
                    }   
                    
                    public void onNothingSelected(AdapterView<?> parent) {
                    	getPosition("Spinner1: unselected");
                    }
                });
	    
	  
	}
	 void getPosition(String msg) {
		 	DemoView japanView = new DemoView(this,msg.toString());
		 	final LinearLayout root = (LinearLayout) findViewById(R.id.myscreen);
		 	root.addView(japanView, 2);
	    }
	 
	private class DemoView extends View{
		public String shape = "";
		public DemoView(Context context){
			super(context);
		}
		
		public DemoView(Context context,String xshape){
			super(context);
			this.shape = xshape;
		}

		@Override protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			int x = 0;
			int y = 0;
			Paint paint = new Paint();
			paint.setStyle(Paint.Style.FILL);

			// make the entire canvas white
			paint.setColor(Color.WHITE);
			canvas.drawPaint(paint);
			// another way to do this is to use:
			// canvas.drawColor(Color.WHITE);
			
			if("2".equals(shape))
			{
				  //draw a circle
				
				final int width = getWidth();
				final int height = getHeight();
				paint.setColor(Color.GREEN);

				final float radius = .2f * width;
				canvas.drawCircle(width / 2.0f, height / 2.0f, radius, paint);	
			}
			if("1".equals(shape)){
				paint.setAntiAlias(false);
				paint.setColor(Color.RED);
				canvas.drawRect(10, 10, 400, 100, paint);
				}
			if("3".equals(shape)){
				paint.setAntiAlias(true);
				paint.setColor(Color.RED);
				paint.setStyle(Paint.Style.FILL); 
				paint.setStrokeWidth(4.5f);
				// opacity
				//p.setAlpha(0x80); //
	 
				canvas.drawOval(new RectF(50, 50, 400, 100), paint);;
				
			}
			
		}
	}
}